from pathlib import Path

import joblib
import pandas as pd
import streamlit as st

from src.data_loader import prepare_data
from src.preprocess import clean_data
from src.eda import (
    dataset_summary,
    user_activity_stats,
    product_popularity_stats,
    sparsity_info,
)
from src.model_train import (
    encode_ids,
    build_sparse_matrix,
    apply_svd,
    compare_clustering_models,
    attach_cluster_labels,
)
from src.recommender import recommend_products, recommend_popular_products


BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "rating_short.csv"
ARTIFACT_DIR = BASE_DIR / "artifacts"
PLOTS_DIR = BASE_DIR / "plots"


@st.cache_data(show_spinner=False)
def load_and_clean_data() -> pd.DataFrame:
    df = prepare_data(str(DATA_PATH))
    df = clean_data(df)
    df["userId"] = df["userId"].astype(str)
    df["productId"] = df["productId"].astype(str)
    return df


def build_results_table_from_artifact(model_name: str, labels) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "model_name": f"{model_name} (pretrained)",
                "n_clusters": int(pd.Series(labels).nunique()),
                "silhouette_score": "Loaded artifact",
                "davies_bouldin_score": "Loaded artifact",
                "calinski_harabasz_score": "Loaded artifact",
            }
        ]
    )


def load_pretrained_clusters(df: pd.DataFrame):
    user_encoder = joblib.load(ARTIFACT_DIR / "user_encoder.pkl")
    cluster_model = joblib.load(ARTIFACT_DIR / "cluster_model.pkl")

    labels = getattr(cluster_model, "labels_", None)
    users = pd.Series(user_encoder.classes_).astype(str)

    if labels is None:
        raise ValueError("Pretrained cluster model does not contain labels_.")

    if len(users) != len(labels):
        raise ValueError("Artifact user count and cluster-label count do not match.")

    cleaned_users = set(df["userId"].astype(str).unique())
    artifact_users = set(users.tolist())

    if cleaned_users != artifact_users:
        raise ValueError("Artifact users do not match the cleaned dataset users.")

    user_cluster_df = pd.DataFrame(
        {
            "userId": users,
            "user_index": range(len(users)),
            "cluster": labels,
        }
    )

    model_name = cluster_model.__class__.__name__
    results_df = build_results_table_from_artifact(model_name, labels)
    return user_cluster_df, results_df, model_name


def train_clusters_at_runtime(df: pd.DataFrame):
    df_encoded, _, _ = encode_ids(df)
    matrix = build_sparse_matrix(df_encoded)
    features, _ = apply_svd(matrix, n_components=20)
    results_df, fitted_models, labels_map = compare_clustering_models(features, n_clusters=5)

    best_model_name = results_df.iloc[0]["model_name"]
    best_labels = labels_map[best_model_name]
    user_cluster_df = attach_cluster_labels(df_encoded, best_labels)
    return user_cluster_df, results_df, best_model_name


@st.cache_resource(show_spinner="Loading recommendation system...")
def build_recommendation_system():
    df = load_and_clean_data()

    try:
        user_cluster_df, results_df, best_model_name = load_pretrained_clusters(df)
        source = "Pretrained artifacts"
    except Exception:
        user_cluster_df, results_df, best_model_name = train_clusters_at_runtime(df)
        source = "Runtime training fallback"

    return df, user_cluster_df, results_df, best_model_name, source


def show_saved_plot(filename: str, caption: str) -> None:
    plot_path = PLOTS_DIR / filename
    if plot_path.exists():
        st.image(str(plot_path), caption=caption, use_container_width=True)
    else:
        st.info(f"Plot file not found: {filename}")


def main() -> None:
    st.set_page_config(
        page_title="Product Recommendation System",
        page_icon="🛒",
        layout="wide",
    )

    st.title("Product Recommendation System")
    st.write(
        "A cluster-based product recommendation app using collaborative filtering, "
        "TruncatedSVD, clustering, and popularity fallback recommendations."
    )

    df, user_cluster_df, results_df, best_model_name, source = build_recommendation_system()

    summary = dataset_summary(df)
    user_stats = user_activity_stats(df)
    product_stats = product_popularity_stats(df)
    sparse_stats = sparsity_info(df)

    st.subheader("Dataset Overview")
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Rows", f"{summary['rows']:,}")
    col2.metric("Users", f"{summary['unique_users']:,}")
    col3.metric("Products", f"{summary['unique_products']:,}")
    col4.metric("Ratings", f"{summary['total_ratings']:,}")

    st.subheader("Model Status")
    status_col1, status_col2 = st.columns(2)
    status_col1.success(f"Best model: {best_model_name}")
    status_col2.info(f"Source: {source}")

    st.subheader("Key Statistics")
    stats_col1, stats_col2, stats_col3 = st.columns(3)

    with stats_col1:
        st.write("User Activity")
        st.dataframe(pd.DataFrame([user_stats]), use_container_width=True)

    with stats_col2:
        st.write("Product Popularity")
        st.dataframe(pd.DataFrame([product_stats]), use_container_width=True)

    with stats_col3:
        st.write("Sparsity")
        st.dataframe(pd.DataFrame([sparse_stats]), use_container_width=True)

    st.subheader("Clustering Model Summary")
    st.dataframe(results_df, use_container_width=True)

    st.subheader("EDA Plots")
    plot_col1, plot_col2, plot_col3 = st.columns(3)
    with plot_col1:
        show_saved_plot("rating_distribution.png", "Rating Distribution")
    with plot_col2:
        show_saved_plot("top_products.png", "Top Products")
    with plot_col3:
        show_saved_plot("top_users.png", "Top Users")

    st.subheader("Generate Recommendations")
    available_users = df["userId"].drop_duplicates().sort_values().tolist()

    rec_col1, rec_col2 = st.columns([2, 1])
    with rec_col1:
        selected_user = st.selectbox("Select User ID", available_users, index=0)
        custom_user = st.text_input("Or enter a User ID manually", value=selected_user)
    with rec_col2:
        top_n = st.slider("Number of Recommendations", min_value=5, max_value=20, value=10)

    user_id = str(custom_user).strip()

    if st.button("Recommend Products", type="primary"):
        if not user_id:
            st.warning("Please enter a valid User ID.")
            return

        if user_id in set(df["userId"].astype(str).values):
            recommendations = recommend_products(
                df=df,
                user_cluster_df=user_cluster_df,
                user_id=user_id,
                top_n=top_n,
            )
            st.success(f"Recommendations generated for user: {user_id}")
        else:
            recommendations = recommend_popular_products(df=df, user_id=None, top_n=top_n)
            st.info("User not found. Showing popular product recommendations instead.")

        if recommendations.empty:
            st.warning("No recommendations found.")
        else:
            st.dataframe(recommendations, use_container_width=True)


if __name__ == "__main__":
    main()
