# P655 Product Recommendation System

A Streamlit-based product recommendation system for e-commerce ratings data. The app performs data cleaning, exploratory analysis, user-item matrix construction, dimensionality reduction with TruncatedSVD, clustering-based recommendation, and popularity-based fallback recommendation.

## Live Deployment Platform

Use **Streamlit Community Cloud** for this project. GitHub Pages will not run this app because the project requires Python, Streamlit, scikit-learn, and model artifacts.

## Project Structure

```text
P655_Product_Recommendation/
├── streamlit_app.py
├── app.py
├── requirements.txt
├── runtime.txt
├── README.md
├── .gitignore
├── .streamlit/
│   └── config.toml
├── src/
│   ├── __init__.py
│   ├── data_loader.py
│   ├── preprocess.py
│   ├── eda.py
│   ├── model_train.py
│   └── recommender.py
├── data/
│   └── rating_short.csv
├── artifacts/
│   ├── cluster_model.pkl
│   ├── product_encoder.pkl
│   ├── svd_model.pkl
│   └── user_encoder.pkl
└── plots/
    ├── rating_distribution.png
    ├── top_products.png
    └── top_users.png
```

## Local Run

```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Streamlit Cloud Deployment

1. Push this folder to GitHub.
2. Open Streamlit Community Cloud.
3. Create a new app from your GitHub repository.
4. Select the `main` branch.
5. Set the main file path as:

```text
streamlit_app.py
```

6. Deploy.

## Notes

- `streamlit_app.py` is the deployment entry point.
- `app.py` is a command-line pipeline script.
- `src/__init__.py` is included so imports work correctly on hosted runtimes.
- `.pyc` and `__pycache__` files are excluded from deployment.
- Pretrained artifacts are loaded first for fast deployment. If artifact loading fails, the app falls back to runtime training.
